#include <SFML\Graphics.hpp>
#include <algorithm>
#include <chrono>
#include <random>
#include <vector>

#include "oth/drawText.cpp"
#include "oth/drawRect.cpp"

template <typename T>
void scambia(T &x, T &y) { // scambia
    T tmp = x;
    x = y;
    y = tmp;
}

#ifndef ___CELLS_VISUALIZATION_TABLE_
#define ___CELLS_VISUALIZATION_TABLE_

class CellTable {
private:
    std::vector<unsigned short int> NUMBERS;
    std::vector<bool> CHECKED;
    unsigned short CELL_NUM;

    float window_x_max=0,window_y_max=0;
public:
    CellTable(unsigned NumCells) {
        srand(time(NULL));
        CELL_NUM = NumCells;

        //prepara vettore
        for(int i = 0; i < CELL_NUM; i++){
            NUMBERS.push_back(i + 1);
            CHECKED.push_back(true);
        }

        //non selezionare nessuno
        check_all(false);
    }

    // main functions
    void draw(sf::RenderWindow &i_window);
    void shuffle();
    void resolve();
    //check vector functions
    void check_all(bool value);
    bool is_check_element(unsigned short value);
    void toggle_check_element(unsigned short value);
};

// disordina vettore
void CellTable::shuffle(){
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    check_all(true);
    std::shuffle(NUMBERS.begin(), NUMBERS.end(), std::default_random_engine(seed));
    check_all(false);
}

// disegna
void CellTable::draw(sf::RenderWindow& i_window){
    window_x_max=i_window.getSize().x;
    window_y_max=i_window.getSize().y;

    sf::Color color(255,255,255);
    for(int i = 0; i < CELL_NUM; i++){
        if(is_check_element(i+1)){//check -> red
            color.r = 255;
            color.g = 0;
            color.b = 0;
        }else{//not check -> white
            color.r = 255;
            color.g = 255;
            color.b = 255;
        }

        drawText(std::to_string(NUMBERS.at(i)),((window_x_max-10)/CELL_NUM)*i,50,window_x_max/(CELL_NUM*2),i_window,sf::Color::White);
        drawRect_r(((window_x_max) / CELL_NUM) * i, window_y_max - 20, (window_x_max / CELL_NUM) / 1, ( NUMBERS.at(i)  + 1) * (window_y_max / (CELL_NUM * 1.5)), i_window, color);
    }
}

// risolvi
void CellTable::resolve(){
    int n = NUMBERS.size();
    //bubble_sort(NUMBERS);

    //bubble sort
    for(int i = 0; i < n - 1; i++) {
        for(int j = 0; j < n - 1 - i; j++) {
            if(NUMBERS[j] > NUMBERS[j + 1]) {
                scambia(NUMBERS[j], NUMBERS[j + 1]);
            }
        }
    }
}

void CellTable::check_all(bool value){
    for(int i=0;i<CELL_NUM;i++) CHECKED.at(i)=value;
}
bool CellTable::is_check_element(unsigned short value){
    int pos=0;
    for(int i=0;i<CELL_NUM;i++){
        if(NUMBERS[i]==value) pos=i;
    }

    return CHECKED[pos];
}
void CellTable::toggle_check_element(unsigned short value){
    int pos=0;
    for(int i=0;i<CELL_NUM;i++) {
        if(NUMBERS[i]==value) pos=i;
    }

    CHECKED[pos] = !CHECKED[pos];
}
#endif //#!___CELLS_VISUALIZATION_TABLE_
