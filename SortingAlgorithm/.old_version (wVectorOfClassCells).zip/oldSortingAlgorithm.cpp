#include <SFML\Graphics.hpp>

#include <windows.h>

#include "oth/drawText.cpp"
#include "cellsort.cpp"

//versione 2.0
#include "sort.cpp"

int main(int argc, char** argv) {
    sf::RenderWindow window;
    setFontPath("oth\\consola.ttf");

    //prima volta
    bool primo_avvio=true;

    //imposto il valore di argomento
    unsigned value,  screenW,screenH;
    if(argc>1){//maggiore di 1 argomento
        value = std::stoi(argv[1]);
        if(value > 1024 || value < 5) value = 256;
        MessageBox(0, "Argomento accettato!", "SortingAlgorithm", MB_OK | MB_ICONASTERISK);

        if(argc>=3){//maggiore di 3 argomenti
            screenW = std::stoi(argv[2]), screenH = std::stoi(argv[3]);
            if((screenW<640 && screenH<360) || (screenW>1920 && screenH>1080)){screenW=1280;screenH=720;}
        }else{//tra 3 e 1 argomento
            screenW=1280;screenH=720;
        }
    }else{//non ci sono argomenti
        MessageBox(0, "Non ci sono argomenti validi.", "SortingAlgorithm", MB_OK | MB_ICONEXCLAMATION);
        value = 256;
        screenW=1280;screenH=720;
    }
    MessageBox(0, "R: risolvi (resolve)\nS: disordina (shuffle)\nV: visualizza (show)", "SortingAlgorithm Comandi:", MB_OK | MB_ICONASTERISK);

    window.create(sf::VideoMode(screenW,screenH), "SFML PROJECT 1#",sf::Style::Titlebar | sf::Style::Close);

    CellSortingTable a(value);

    sf::Event event;
    while (window.isOpen()){

        //input
        while (window.pollEvent(event)){
            switch(event.type){
                case sf::Event::Closed:
                    window.close();
                    break;
                case sf::Event::KeyPressed:
                    switch(event.key.code){
                        case sf::Keyboard::S:
                            a.shuffle();
                            break;
                        case sf::Keyboard::V:
                            a.visualize();
                            break;
                        case sf::Keyboard::R:
                            a.resolve();
                            break;
                    }
                    primo_avvio=false;
                    break;
            }
        }

        //draw
        window.clear(sf::Color(0,0,0));

        drawText(("Sorting Algorithm: Num=" + std::to_string(value)).c_str(), 10, 0, 40, window, true);
        
        if(primo_avvio) drawText("Premi il tasto V\nper visualizzare i valori dei vettori..", 0,window.getSize().y/2,50, window, true);

        a.draw(window);

        window.display();
    }

    return 0;
}