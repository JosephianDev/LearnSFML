#include <SFML/Graphics.hpp>
#include <algorithm>
#include <chrono>
#include <random>
#include <vector>

#include "oth/drawText.cpp"

template<typename T>void scambia(T &x, T &y) { // scambia
    T tmp = x;
    x = y;
    y = tmp;
}

#ifndef __CELL_SORTING_TABLE_HCPP_CLASS
#define __CELL_SORTING_TABLE_HCPP_CLASS

// SINGLE CELLS ----------------------------------------------------------------
class Cell {
private:
    unsigned int value;
    sf::RectangleShape rect;

public:
    //get and set value
    unsigned int control_state(int state) { // get value
        if(state==1){// controlling
            rect.setFillColor(sf::Color::Red);
            return value;
        }else{// normal or default
            rect.setFillColor(sf::Color::White);
            return 0;
        }
    }
    void setValue(unsigned int value) { // set value
        this->value = value;
    }
    //get and set shape
    sf::RectangleShape getRect(){
        return rect;
    }
    void setRect(float pos_x,float pos_y,float width,float height){
        rect.setPosition(sf::Vector2f(pos_x,pos_y));
        rect.setSize(sf::Vector2f(width,height));
        //imposto le origini in basso a sinistra
        rect.setOrigin(0, rect.getSize().y);
    }

    //constructor
    Cell() {
    }
};

//------------------------------------------------------------
// THE TABLE FOR VISUALIZATION

class CellSortingTable {
private:
    std::vector<Cell> CELLS;
    unsigned short CELL_NUM;

    float window_x_max=0,window_y_max=0;
public:
    CellSortingTable(unsigned NumCells) {
        srand(time(NULL));
        CELL_NUM = NumCells;
        prepare();
    }

    //main functions
    void draw(sf::RenderWindow &i_window);
    void shuffle();
    void prepare();
    void visualize();
    void resolve();


    //bubble sort
    void bubble_sort(){
        for(int i = 0; i < CELLS.size() - 1; i++) {
            for(int j = i + 1; j < CELLS.size(); j++) {
                if(CELLS.at(i).control_state(1) > CELLS.at(j).control_state(1)) {
                    scambia(CELLS.at(i), CELLS.at(j));

                    CELLS.at(i).control_state(0);
                    CELLS.at(j).control_state(0);

                    sf::sleep(sf::seconds(5.0f));
                }

                sf::sleep(sf::seconds(5.0f));
            }
            sf::sleep(sf::seconds(5.0f));
        }
    }
};

//prepara
void CellSortingTable::prepare(){
    Cell* temp;
    
    for(int i=0;i<CELL_NUM;i++){
        temp=new Cell;
        temp->setValue(i+1);
        // i_window.getSize()
        temp->setRect(  ((window_x_max/* togliendo dei numeri si aumenta il margine destro */)/CELL_NUM)*i  ,  window_y_max-20 /* margine da sotto */  ,  (window_x_max/CELL_NUM)/1 /* aumentando questo numero aumenti lo spazio */  ,  ( temp->control_state(1) +1) * (window_y_max/(CELL_NUM*1.5))  );
        CELLS.push_back(*temp);
        delete temp;
    }
}

//visualizza vettore
void CellSortingTable::visualize(){
    for(int i=0;i<CELL_NUM;i++) CELLS.at(i).setRect(((window_x_max)/CELL_NUM)*i,window_y_max-20,(window_x_max/CELL_NUM)/1,(CELLS.at(i).control_state(1)+1)*(window_y_max/(CELL_NUM * 1.5)));
}

//disordina vettore
void CellSortingTable::shuffle(){
    unsigned seed = std::chrono::system_clock::now().time_since_epoch().count();
    std::shuffle(CELLS.begin(), CELLS.end(), std::default_random_engine(seed));

    visualize();
}

//risolvi vettore
void CellSortingTable::resolve() {
    bubble_sort();
}

//disegna (sub visualizza)
void CellSortingTable::draw(sf::RenderWindow& i_window){
    window_x_max=i_window.getSize().x;
    window_y_max=i_window.getSize().y;
    

    for(int i=0;i<CELLS.size();i++){
        i_window.draw(CELLS.at(i).getRect());
        drawText(std::to_string(CELLS.at(i).control_state(1)),((i_window.getSize().x-10)/CELL_NUM)*i,50,i_window.getSize().x/(CELL_NUM*2),i_window,true);
        CELLS.at(i).control_state(0);
    }
}

/*
Le celle sono le line dei valori
*/
#endif //#! __CELL_SORTING_TABLE_HCPP_CLASS